Alex Doner, E.O Rafelson
CSCI 2270
Final Project

miniGit Repository system
1. This program creates directory called .miniGit in the working directory and allows the user to have basic revision control. 
2. The user can add and remove files, commit, and checkout any version of the repository by following the instructions presented by the program.
3. If the user decides to check out an older version, the repository will automatically prevent the user from trying to commit any changes until they checkout the current version.
4. This repository will store exact copies of each committed version of all files while the program is running.
5. Once the program is closed the .minigit directory and all its contents will be deleted. 

